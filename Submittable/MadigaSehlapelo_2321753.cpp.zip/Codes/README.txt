Student NUMBER : 2321753

---------------------------------------------------------------------------------------------------------------------------
This file explains how to run the program on a terminal.
---------------------------------------------------------------------------------------------------------------------------

The input file is stored in the files directory. The results file is written
to the files directory as well.

---------------------------------------------------------------------------------------------------------------------------

TO RUN THE CODE RUN THE FOLLOWING COMMANDS ON THE TERMINAL.

$ make && ./run.sh

----------------------------------------------------------------------------------------------------------------------------

The make file handles the compiling of the code with it's header files